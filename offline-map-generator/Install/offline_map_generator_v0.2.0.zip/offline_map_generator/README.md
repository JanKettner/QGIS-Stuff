# Offline Map Generator 0.2.0

Separates QGIS-Plugin zur automatischen Erstellung offline nutzbarer OSM-Projekte.

## Neu in 0.2.0

- Geofabrik-Katalog wird automatisch geladen.
- Aktueller Kartenausschnitt wird nach WGS84 transformiert.
- Kleinster Geofabrik-Extrakt, dessen Begrenzungsbox den Ausschnitt umfasst, wird vorgeschlagen.
- Regionalextrakt wird im Hintergrund heruntergeladen.
- Downloadfortschritt und Protokoll.
- Zuschnitt mit `osmium extract`.
- Konvertierung in GeoPackage mit `ogr2ogr`.
- QGIS-Projekt wird erzeugt und geöffnet.
- Alternativ kann weiterhin eine lokale `.osm.pbf` verwendet werden.
- Qt5-/Qt6-kompatibel für QGIS 3.28 bis QGIS 4.x.

## Voraussetzungen

- `osmium.exe` (osmium-tool)
- `ogr2ogr.exe` (normalerweise Bestandteil von QGIS/OSGeo4W)

## Bedienung

1. Plugin über **Erweiterungen → Aus ZIP installieren** installieren.
2. Gewünschten Kartenausschnitt in QGIS einstellen.
3. **Offline Map Generator** öffnen.
4. **Aktuellen QGIS-Kartenausschnitt übernehmen** klicken.
5. Vorgeschlagenen Geofabrik-Extrakt prüfen.
6. Ausgabeordner und Projektname angeben.
7. Pfade zu `osmium.exe` und `ogr2ogr.exe` prüfen.
8. **Herunterladen und Offline-Karte erstellen** starten.

## Hinweis zum automatischen Vorschlag

Die automatische Auswahl nutzt die Begrenzungsboxen der Geofabrik-Regionen. Bei Grenzgebieten oder überlappenden Spezialextrakten sollte die vorgeschlagene Region manuell geprüft werden.

Geofabrik stellt einen maschinenlesbaren GeoJSON-Katalog unter `https://download.geofabrik.de/index-v1.json` bereit. Die OSM-Extrakte werden üblicherweise täglich aktualisiert.
